

def check_input(arr):
    count1 = 0
    count = 0
    x = len(arr[0])
    for i in range(0,x):
        for j in range(1,x):
            if(arr[i][0]==arr[i][j] or type(arr[i][j])==str):
                count1 = count1 + 1
    
    for j in range(0,3):
        for i in range(1,3):
            if(arr[0][j]==arr[i][j] or type(arr[i][j])==str):
                count = count + 1
    if(count1==0 and count==0):
        return True
    else:
        return False
    
    
    # run this block to test code after defining the procedure

test1 = [[1, 2, 3],
        [2, 3, 1],
        [3, 1, 2]]

test2 = [[1, 2, 3, 4],
        [2, 3, 1, 3],
        [3, 1, 2, 3],
        [4, 4, 4, 4]]

test3 = [['a', 'b', 'c'],
        ['b', 'c', 'a'],
        ['c', 'a', 'b']]

print(check_input(test1)) # must return true
print(check_input(test2)) # must return false
print(check_input(test3)) # must return false